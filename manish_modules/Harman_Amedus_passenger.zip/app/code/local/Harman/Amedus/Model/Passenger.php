<?php

class Harman_Amedus_Model_Passenger extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("amedus/passenger");

    }

}
	 