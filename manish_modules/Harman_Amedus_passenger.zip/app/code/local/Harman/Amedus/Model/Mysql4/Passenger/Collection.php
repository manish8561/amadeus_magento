<?php
    class Harman_Amedus_Model_Mysql4_Passenger_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("amedus/passenger");
		}

		

    }
	 