<?php   
class Harman_Amedus_Block_Index extends Mage_Core_Block_Template{   





}