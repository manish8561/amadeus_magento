<?php
class Harman_Amedus_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 